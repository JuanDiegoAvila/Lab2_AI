# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fcaBayesian']

package_data = \
{'': ['*']}

install_requires = \
['pgmpy>=0.1.15,<0.2.0']

entry_points = \
{'console_scripts': ['fcaBayesian = fcaBayesian:main']}

setup_kwargs = {
    'name': 'fcabayesian',
    'version': '0.2.0',
    'description': '',
    'long_description': '',
    'author': 'JuanDiegoAvila',
    'author_email': 'avi20090@uvg.edu.gt',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
