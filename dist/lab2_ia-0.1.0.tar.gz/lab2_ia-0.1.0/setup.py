# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lab2_ia']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'lab2-ia',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'JuanDiegoAvila',
    'author_email': 'avi20090@uvg.edu.gt',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
